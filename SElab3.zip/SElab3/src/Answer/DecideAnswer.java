package Answer;

/**
 * Created by Qizixi on 5/29/2016.
 */
public class DecideAnswer extends TextAnswer{

    @Override
    public String getType() {
        return "decision";
    }

}
