package Answer;

import java.awt.*;

/**
 * Created by Qizixi on 5/29/2016.
 */
public class RankAnswer extends ListAnswer{

    @Override
    public String getType() {
        return "rank";
    }

}
