package Answer;

import java.util.List;

/**
 * Created by Qizixi on 5/29/2016.
 */
public class ChoiceAnswer extends TextAnswer{

    @Override
    public String getType() {
        return "choice";
    }
}
