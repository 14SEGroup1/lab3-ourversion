package Paper;

import Answer.Answer;;

public class IteratorAnswer implements Iterator<Answer>{
		
		int answerIndex = 0;
		
		@Override
		public boolean hasNext(Paper page) {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public Answer next() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			return false;
		}	
	}
